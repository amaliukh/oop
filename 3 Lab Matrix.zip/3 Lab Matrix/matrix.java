public class matrix {
	public static void main(String args[]){
int j = 0;
		for (int i = 0 ; i<5; i++) {
			for (int k = 0; k<5; k++) {
				 j++;	
				 if(j==1 | j==5 | j==7 | j== 9 | j==13 | j== 17 | j==19 | j==21 | j==25) {
          System.out.print(" ");
					 System.out.print("*");
       System.out.print(" ");
       
				 }
				 else {
					 if (j<10) {   System.out.print(" ");
						 System.out.print(j);
	       System.out.print(" ");}
	       else {System.out.print(j);
	       System.out.print(" ");}
				 }
       
			}
			
			System.out.println();
		}
	}
}